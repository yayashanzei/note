<?php

class Db
{
    protected $pdo;
    protected $res;
    protected $config;

    public function __construct($config)
    {
        $this->Config = $config;
        $this->connect();
    }

    public function connect()
    {
        $this->pdo = new PDO($this->Config['dsn'], $this->Config['name'], $this->Config['password']);
        $this->pdo->query('set names utf8;');
//把结果序列化成stdClass
//$this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
//自己写代码捕获Exception
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function close()
    {
        $this->pdo = null;
    }

    public function query($sql)
    {
        $res = $this->pdo->query($sql);
        if ($res) {
            $this->res = $res;
        }
        return $this;
    }

    public function exec($sql)
    {
        $res = $this->pdo->exec($sql);
        if ($res) {
            $this->res = $res;
        }
        return $res;
    }

    public function fetchAll()
    {
        return $this->res->fetchAll();
    }

    public function fetch()
    {
        return $this->res->fetch();
    }

    public function fetchColumn()
    {
        return $this->res->fetchColumn();
    }

    public function lastInsertId()
    {
        return $this->res->lastInsertId();
    }

}
$gets = $_GET;
if(!isset($gets['key'])||$gets['key']!=md5('icebr123,./')){
    echo json_encode(array('code'=>500));
    exit;
}

$dsn = 'mysql:host=localhost;dbname=wnwbthuser';
$username = 'root';
$password = 'eastdaydongfang654321';
$lists = array();

$db = new Db(array('dsn' => $dsn, 'name' => $username, 'password' => $password));

$start = strtotime(date('Ymd'));
$where = " where LastUptime>{$start}";

$todayQQOnline = "select count(UserID) as users from qq_userinfo{$where}";
$todaySinaOnline = "select count(UserID) as users from sina_userinfo{$where}";
$todayWnwbOnline = "select count(UserID) as users from wnwb_userinfo{$where}";

$totalOnline = "select count(userid) as users,login_type from global_unique_id GROUP BY login_type";

$qqUsers = $db->query($todayQQOnline)->fetchAll();
$sinaUsers = $db->query($todaySinaOnline)->fetchAll();
$wnwbUsers = $db->query($todayWnwbOnline)->fetchAll();
$totalUsers = $db->query($totalOnline)->fetchAll();

$qqUsers = $qqUsers[0];
$sinaUsers = $sinaUsers[0];
$wnwbUsers = $wnwbUsers[0];
$totalUsers = $totalUsers;

$result = array();
$result['total'] = 0;

isset($qqUsers['users']) ? $result['qq'] = $qqUsers['users'] : 0;
isset($sinaUsers['users']) ? $result['sina'] = $sinaUsers['users'] : 0;
isset($wnwbUsers['users']) ? $result['wnwb'] = $wnwbUsers['users'] : 0;
if (!empty($totalUsers) && is_array($totalUsers)) {
    foreach ($totalUsers as $tv) {
        $result[$tv['login_type'] . '_total'] = $tv['users'];
        $result['total'] = $result['total'] + $result[$tv['login_type'] . '_total'];
    }
}

$result['today'] = $result['qq'] + $result['sina'] + $result['wnwb'];

$insert = "INSERT INTO `history` (`qq`, `sina`, `wnwb`, `today`, `qq_total`,`sina_total`,`wnwb_total`,`total`,`date`) VALUES ({$result['qq']}, {$result['sina']},{$result['wnwb']},{$result['today']},{$result['qq_total']},{$result['sina_total']},{$result['wnwb_total']},{$result['total']},{$start})";
$existsSql = "select id from history where date={$start}";
$existsId = $db->query($existsSql)->fetchColumn();
if ($existsId !== false && !empty($existsId)) {
    $insert = "UPDATE `history` SET `qq`={$result['qq']}, `sina`={$result['sina']}, `wnwb`={$result['wnwb']}, `today`={$result['today']}, `qq_total`={$result['qq_total']}, `sina_total`={$result['sina_total']}, `wnwb_total`={$result['wnwb_total']}, `total`={$result['total']}, `date`={$start} WHERE (`id`={$existsId})";
}
$rs = $db->exec($insert);
exit;

?>
