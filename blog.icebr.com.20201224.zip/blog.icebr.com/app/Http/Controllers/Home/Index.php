<?php
/**
 * Created by PhpStorm.
 * User: icebr:ice_br2046@163.com
 * Date: 17-7-20
 * Time: 下午4:31
 */

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use App\Http\Controllers\Common\Home;
use App\Http\Traits\Home\Construct;
use Illuminate\Support\Facades\DB;
use Illuminate\Container\Container;
use Illuminate\Support\Facades\Storage;
use Illuminate\Contracts\View\Factory as ViewFactory;

use App\Http\Lib\Tree;
use phpQuery;

class Index extends Home
{
    use Construct;

    public function __construct(Request $request)
    {
        $this->construct($request);
    }

    public function index(Request $request)
    {
        $this->initLeft($request);
        $notes = $this->getNoteList($request);
        return view($this->skin . 'index.main', [
            'blog' => 'my first blog by laravel',
            'skin' => $this->skin,
            'path' => $this->path,
            'notes' => $notes,
        ]);
    }


    public function moveCategory(Request $request)
    {
        $params = $request->all();

        $options = $this->getCategorySelect($request);

        return view($this->skin . 'index.moveCategory', [
            'options' => $options,
            'path' => $this->path,
            'skin' => $this->skin,
        ]);
    }

    private function getCategorySelect(Request $request)
    {
        $options = '';

        $list = DB::table('category')->where(array('uid' => $this->userInfo['uid'], 'status' => 1))->get(['id', 'name', 'title', 'uid', 'up_uid', 'origin_uid', 'pid', 'tid', 'allow_publish'])->toArray();

        if (!empty($list)) {
            foreach ($list as &$lv) {
                $lv = (array)$lv;
                $lv['parent_id'] = $lv['pid'];
            }

            $tree = new Tree();

            $str = '<option value=\"$id\" $selected>$spacer $title</option>';

            $tree->init($list);
            $options = $tree->getTree(0, $str);
        }

        return $options;
    }

    public function doMoveCategory(Request $request)
    {
        $params = $request->all();

        if (!isset($params['node']['id']) || !isset($params['target']['id']) || !isset($params['target']['tid'])) {
            echo 'error';
            exit;
        }

        $time = time();

        $data = array('pid' => $params['target']['id'], 'tid' => $params['target']['tid'], 'update_time' => $time);

        $rs = DB::table('category')->where(array('id' => $params['node']['id']))->update($data);

        if ($rs !== false) {
            return 'success';
        } else {
            return 'fail';
        }

    }

    public function moveNote(Request $request)
    {
        $params = $request->all();

        $options = $this->getCategorySelect($request);

        return view($this->skin . 'index.moveNote', [
            'options' => $options,
            'path' => $this->path,
            'skin' => $this->skin,
        ]);

    }

    public function doMoveNote(Request $request)
    {
        $params = $request->all();

        if (!isset($params['note']['id']) || !isset($params['target']['id'])) {
            echo 'error';
            exit;
        }

        $time = time();

        $data = array('category_id' => $params['target']['id'], 'update_time' => $time);

        $rs = DB::table('note')->where(array('id' => $params['note']['id']))->update($data);

        if ($rs !== false) {
            return 'success';
        } else {
            return 'fail';
        }

    }

    public function addNote(Request $request)
    {
        $params = $request->all();

        if (!isset($params['id']) || empty($params['id']) || empty($params['uid'])) {
            echo 'error';
            exit;
        }

        $data = $content = array();
        $noteId = null;
        $time = time();

        $data['uid'] = $params['uid'];
        $data['up_uid'] = 0;
        $data['origin_uid'] = 0;
        $data['category_id'] = $params['id'];
        $data['title'] = '';
        $data['name'] = '';
        $data['content'] = '';
        $data['cover'] = 0;
        $data['views'] = 0;
        $data['status'] = 1;
        $data['description'] = '';
        $data['sort'] = 0;
        $data['keywords'] = '';
        $data['create_time'] = $time;
        $data['update_time'] = $time;

        $content['parse'] = 0;
        $content['content'] = '';
        $content['template'] = '';
        $content['bookmark'] = 0;

        $data = DB::transaction(function () use ($noteId, $data, $content) {
            $contentId = DB::table('content')->insertGetId($content);
            $data['content'] = $contentId;
            $noteId = DB::table('note')->insertGetId($data);
            $data['id'] = $noteId;
            return $data;
        }, 3);

        if (isset($data['id']) && is_integer($data['id'])) {
            return json_encode($data);
        } else {
            return 'fail';
        }

    }

    public function deleteNote(Request $request)
    {
        $params = $request->all();

        if (!isset($params['id']) || empty($params['id'])) {
            echo 'error';
            exit;
        }

        $note = (array)DB::table('note')->where(array('id' => $params['id']))->first();

        if (empty($note)) {
            echo 'not_exists';
            exit;
        }

        $content = DB::table('content')->where(array('id' => $note['content']))->value('content');

        $rs = $this->deleteImg($content);

        if (!$rs) {
            echo 'img_delete_fail';
            exit;
        }

        $rs = DB::transaction(function () use ($note) {
            $rs = DB::table('content')->where(array('id' => $note['content']))->delete();
            $rs = DB::table('note')->where(array('id' => $note['id']))->delete();
            return $rs;
        }, 3);

        if ($rs) {
            return 'success';
        } else {
            return 'fail';
        }

    }

    private function deleteImg($content = '')
    {
        $rs = true;

        if (empty($content)) {
            return $rs;
        }

        $reg = "/<[img|IMG].*?src=[\'|\"](.*?(?:[\.gif|\.jpg|\.png|\.bmp]))[\'|\"].*?[\/]?>/";
        preg_match_all($reg, $content, $match);
        if (isset($match[1]) && is_array($match[1])) {
            foreach ($match[1] as $mv) {
                if (strpos($mv, '/upload') !== false) {
                    try {
                        Storage::delete($mv);
                    } catch (\Exception $e) {
                        $rs = false;
                    }
                }
            }
        }

        return $rs;
    }

    public function addCategory(Request $request)
    {
        $params = $request->all();

        if (!isset($params['node']) || empty($params['node'])) {
            echo 'error';
            exit;
        }

        $data = array();

        if (!isset($params['node']['pid'])) {
            if (isset($params['node']['tid'])) {
                $data['pid'] = $params['node']['tid'];
                $data['tid'] = $params['node']['tid'];
            } else {
                $data['pid'] = 0;
                $data['tid'] = 0;
            }
        } else {
            $data['pid'] = $params['node']['pid'];
            $data['tid'] = $params['node']['tid'];
        }

        $time = time();

        $data['uid'] = $this->userInfo['uid'];
        $data['name'] = '';
        $data['title'] = $params['node']['name'];
        $data['up_uid'] = 0;
        $data['origin_uid'] = $this->userInfo['uid'];
        $data['allow_publish'] = 1;
        $data['check'] = 0;
        $data['model'] = 0;
        $data['icon'] = '';
        $data['display'] = 1;
        $data['sort'] = 0;
        $data['list_row'] = 10;
        $data['meta_title'] = '';
        $data['keywords'] = '';
        $data['description'] = '';
        $data['template_index'] = '';
        $data['template_lists'] = '';
        $data['template_detail'] = '';
        $data['template_edit'] = '';
        $data['status'] = 1;
        $data['cataid'] = '0';
        $data['cover'] = 0;
        $data['create_time'] = $time;
        $data['update_time'] = $time;

        $exists = DB::table('category')->where(array('uid' => $data['uid'], 'title' => $data['title'], 'pid' => $data['pid']))->value('id');

        if (!empty($exists)) {
            echo 'exists';
            exit;
        }

        $id = DB::table('category')->insertGetId($data);

        if (is_integer($id)) {
            return $id;
        } else {
            return 'fail';
        }

    }


    public function deleteCategory(Request $request)
    {
        $params = $request->all();

        if (!isset($params['id']) || empty($params['id'])) {
            echo 'error';
            exit;
        }

        if (!isset($params['uid']) || empty($params['uid'])) {
            echo 'error';
            exit;
        }

        $exists = DB::table('category')->where(array('pid' => $params['id']))->value('id');

        if (!empty($exists)) {
            echo 'exists_child';
            exit;
        }

        $exists = DB::table('note')->where(array('category_id' => $params['id']))->value('id');

        if (!empty($exists)) {
            echo 'exists_blog';
            exit;
        }

        $rs = DB::table('category')->where('id', $params['id'])->delete();

        if ($rs) {
            return 'success';
        } else {
            return 'fail';
        }

    }


    public function categoryRename(Request $request)
    {
        $params = $request->all();

        if (!isset($params['id']) || empty($params['id'])) {
            echo 'error';
            exit;
        }

        if (!isset($params['name']) || empty($params['name'])) {
            echo 'error';
            exit;
        }

        $rs = DB::table('category')->where('id', $params['id'])->update(array('title' => $params['name'], 'update_time' => time()));

        if ($rs) {
            return 'success';
        } else {
            return 'fail';
        }

    }

    public function getNoteList(Request $request)
    {
        $categoryId = $request->get('id');

        if (empty($categoryId)) {
            $notes = DB::table('note')->where(array('uid' => $this->userInfo['uid']))->orderBy('create_time', 'desc')->limit(20)->get(['id', 'title', 'name', 'create_time', 'category_id'])->toArray();
            return $notes;
        } else {
            $notes = DB::table('note')->where(array('category_id' => $categoryId, 'uid' => $this->userInfo['uid']))->get(['id', 'title', 'name', 'create_time', 'category_id'])->toArray();
        }

        return json_encode($notes);

    }


    public function getNoteContent(Request $request)
    {
        $noteId = $request->get('id');

        if (empty($noteId)) {
            echo 'error';
            exit;
        }

        $note = DB::table('note')->where(array('id' => $noteId, 'uid' => $this->userInfo['uid']))->first(['id', 'title', 'name', 'create_time', 'update_time', 'category_id', 'content']);

        if ($note === false || empty($note)) {
            echo 'error';
            exit;
        }

        $note = (array)$note;

        $content = DB::table('content')->where('id', $note['content'])->first(['id', 'content']);

        if (empty($content)) {
            $note['content'] = '';
        } else {
            $note['content'] = $content->content;
        }

        return json_encode($note);

    }

    public function saveNoteContent(Request $request)
    {
        $appPath = Container::getInstance()->make('path');
        include_once($appPath . DS . 'Http' . DS . 'Lib' . DS . 'phpquery' . DS . 'phpQuery' . DS . 'phpQuery.php');

        $noteId = $request->get('id');
        $noteContent = $request->get('content');

        if (empty($noteId)) {
            echo 'error';
            exit;
        }

        if (empty($noteContent)) {
            $noteContent = '';
        }

        /*$pq = phpQuery::newDocumentHTML($noteContent, 'utf-8');
        phpQuery::selectDocument($pq);*/

        /*foreach (phpQuery::pq('img') as $img) {
            $imgs[] = $img->getAttribute('src');
            print_r($img);exit;
            $img->attr('data-id','test');
        }

        var_dump($noteContent);
        exit;*/

        try {
            $note = DB::table('note')->where(array('id' => $noteId, 'uid' => $this->userInfo['uid']))->first(['id', 'title', 'name', 'content']);

            if ($note === false || empty($note)) {
                echo 'error';
                exit;
            }
        } catch (\Exception $exception) {
            echo 'error';
            exit;
        }

        $note = (array)$note;

        $content = DB::table('content')->where(array('id' => $note['content']))->first(['id']);

        $updateTime = substr(microtime(), -10);
        $note['update_time'] = $updateTime;

        try{
            if (empty($content)) {
                DB::transaction(function () use ($noteId, $note, $noteContent, $updateTime) {

                    $content['parse'] = 0;
                    $content['content'] = $noteContent;
                    $content['template'] = '';
                    $content['bookmark'] = 0;

                    $id = DB::table('content')->insertGetId($content);
                    DB::table('note')->where(array('id' => $noteId, 'uid' => $this->userInfo['uid']))->update(array('update_time' => $updateTime, 'content' => $id));

                }, 3);
            } else {
                DB::transaction(function () use ($noteId, $note, $noteContent, $updateTime) {
                    DB::table('note')->where(array('id' => $noteId, 'uid' => $this->userInfo['uid']))->update(array('update_time' => $updateTime));
                    DB::table('content')->where('id', $note['content'])->update(array('content' => $noteContent));
                }, 3);
            }
        }catch(\Exception $e){

        }


        $note['content'] = $noteContent;

        return json_encode($note);

    }

    public function changeTitle(Request $request)
    {
        $noteId = $request->get('id');
        $noteTitle = $request->get('title');

        if (empty($noteId)) {
            echo 'error';
            exit;
        }

        try {
            $updateTime = substr(microtime(), -10);
            $note = DB::table('note')->where(array('id' => $noteId, 'uid' => $this->userInfo['uid']))->update(array('title' => $noteTitle, 'update_time' => $updateTime));
        } catch (\Exception $exception) {
            echo 'error';
            exit;
        }

        return json_encode(array('id' => $noteId, 'title' => $noteTitle, 'update_time' => $updateTime));

    }

    protected function initLeft(Request $request)
    {
        $rs = $this->getCategory();
        Container::getInstance()->make(ViewFactory::class)->share('tree', $rs);
    }

    protected function getCategory()
    {
        $list = DB::table('category')->where(array('uid' => $this->userInfo['uid'], 'status' => 1))->get(['id', 'name', 'title', 'uid', 'up_uid', 'origin_uid', 'pid', 'tid', 'allow_publish'])->toArray();

        $list = $this->categoryList($list);

        return json_encode($list);
    }


    /**
     * 把返回的数据集转换成Tree
     */
    protected function categoryList($list, $pk = 'id', $pid = 'pid', $child = 'children', $root = 0)
    {
        // 创建Tree
        $tree = array();
        if (is_array($list)) {

            // 创建基于主键的数组引用
            $refer = array();
            foreach ($list as $key => $data) {
                $list[$key] = (array)$data;
                $list[$key]['catName'] = $list[$key]['name'];
                $list[$key]['name'] = $list[$key]['title'];
                $list[$key]['open'] = true;
                //$list[ $key ]['nocheck']    = true;
                $refer[$data->$pk] =& $list[$key];
            }

            foreach ($list as $key => $data) {
                // 判断是否存在parent
                $parentId = $data[$pid];
                if ($root == $parentId) {
                    $tree[] =& $list[$key];
                } else {
                    if (isset($refer[$parentId])) {
                        //$refer[ $parentId ]['nocheck'] = false;
                        $parent =& $refer[$parentId];
                        $parent[$child][] =& $list[$key];
                    }
                }
            }
        }

        return $tree;
    }

}
