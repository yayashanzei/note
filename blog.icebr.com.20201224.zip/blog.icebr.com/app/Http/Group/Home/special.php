<?php
	/**
	 * Created by PhpStorm.
	 * User: icebr:ice_br2046@163.com
	 * Date: 17-7-20
	 * Time: 下午4:31
	 */
	return array(
		'facebook/webhook'              => 1 ,
		'configure/facebookcallback'    => 1 ,
		'configure/linkedincallback'    => 1 ,
		'configure/youtubecallback'     => 1 ,
		'user/login'                    => 1 ,
		'user/logout'                   => 1 ,
		'run/index'                     => 1 ,
		'monitor/serverfailover'        => 1 ,
		'run/getkeywords'               => 1 ,
		'run/updaterank'                => 1 ,
		'analytics/analyticsservice'    => 1 ,
		'ice/test'                      => 1 ,
		'ice/test2'                     => 1 ,
		'ice/test3'                     => 1 ,
		'ice/test4'                     => 1 ,
		'ice/test5'                     => 1 ,
		'ice/token'                     => 1 ,
		'ice/bindfb'                    => 1 ,
		'ice/bindfbcallback'            => 1 ,
		'sam/test'                      => 1 ,
		'testcase/create_googlepclient' => 1 ,
		'testcase/people_list'          => 1 ,
		'testcase/search'               => 1 ,
		'testcase/spider'               => 1 ,
		'testcase/index'                => 1 ,
		'testcase/gsearch'              => 1 ,
		'testcase/spider2'              => 1 ,
		'task/serverget'                => 1 ,
		'task/checkkeywords'            => 1 ,
		'redirect/tip'                  => 1 ,
		'captcha/entry'                 => 1 ,
		'captcha/check'                 => 1 ,
	);
