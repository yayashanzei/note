<?php
	/**
	 * Created by PhpStorm.
	 * User: icebr:ice_br2046@163.com
	 * Date: 17-7-20
	 * Time: 下午4:31
	 */
	return array(
		'user/login'                 => 1 ,
		'user/register'              => 1 ,
		'user/trialapply'            => 1 ,
		'user/findpwd'               => 1 ,
		'user/disclaimer'            => 1 ,
		'user/emailfind'             => 1 ,
		'user/mobilefind'            => 1 ,
		'user/get_telnumber'         => 1 ,
		'user/emailsend'             => 1 ,
		'user/email_reset'           => 1 ,
		'user/uname'                 => 1 ,
		'user/uphone'                => 1 ,
		'user/phone_reset'           => 1 ,
		'user/logout'                => 1 ,
		'analytics/analyticsservice' => 1 ,
		'configure/facebookcallback' => 1 ,
		'configure/linkedincallback' => 1 ,
		'configure/youtubecallback'  => 1 ,
		'testcase/search'            => 1 ,
		'testcase/spider'            => 1 ,
		'ice/test'                   => 1 ,
		'ice/test2'                  => 1 ,
		'ice/test3'                  => 1 ,
		'ice/test4'                  => 1 ,
		'ice/test5'                  => 1 ,
		'ice/token'                  => 1 ,
		'ice/bindfb'                 => 1 ,
		'ice/bindfbcallback'         => 1 ,
		
		'sam/test'           => 1 ,
		'testcase/index'     => 1 ,
		'testcase/gsearch'   => 1 ,
		'testcase/spider2'   => 1 ,
		'task/serverget'     => 1 ,
		'task/checkkeywords' => 1 ,
		'redirect/tip'       => 1 ,
		'captcha/entry'      => 1 ,
		'captcha/check'      => 1 ,
	);
