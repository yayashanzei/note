<div class="footer">
    i'm home footer!
</div>