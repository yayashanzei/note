<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e($blog); ?></title>
    <?php echo $baseStatic; ?>

</head>
<body>

<?php echo $__env->make($skin.'header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="main">
    i'm home main!
</div>

<?php echo $__env->make($skin.'footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>

