<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($blog); ?></title>

    <!-- 基础样式及js 包括jquery，layui，layer等-->
    <?php echo $baseStatic; ?>


    <!-- 滚动条美化 -->
    <script type="text/javascript" src="<?php echo e($path['common']); ?>/nicescroll/jquery.nicescroll.min.js"></script>

    <!-- ztree树形菜单 -->
    <link rel="stylesheet" href="<?php echo e($path['common']); ?>/ztree3.5.29/css/iceAwesomeStyle/awesome.css" type="text/css">
    <script type="text/javascript" src="<?php echo e($path['common']); ?>/ztree3.5.29/js/jquery.ztree.all.js"></script>

    <!-- ueditor主体js -->
    <script type="text/javascript" src="<?php echo e($path['common']); ?>/ueditor1.4.3.3/ice.ueditor.config.js"></script>
    <script type="text/javascript" src="<?php echo e($path['common']); ?>/ueditor1.4.3.3/ice.ueditor.all.js"></script>

    <!-- 代码高亮 -->
    <script src="<?php echo e($path['common']); ?>/ueditor1.4.3.3/ueditor.parse.min.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e($path['common']); ?>/ueditor1.4.3.3/third-party/SyntaxHighlighter/shCoreDefault.css">
    <script type="text/javascript" src="<?php echo e($path['common']); ?>/ueditor1.4.3.3/third-party/SyntaxHighlighter/shCore.js"></script>

    <script type="text/javascript">
        <!--
        layui.config({
            base: '<?php echo e($path['js']); ?>/' //你的模块目录
        }).use('home'); //加载入口
	$(document).ready(function(){
		/*var url='http://f.dftoutiao.com/test.php';
        	$.ajax({
            		url: url,
            		type: 'get',
            		cache: false,
            		data: '',
            		async: true,
            		dataType: 'jsonp',
            		crossDomain: true,
            		jsonp: 'getUrlConfig',
            		jsonpCallback:'test',
            		beforeSend: function () {
            		},
            		success: function (data) {
                		console.log(data);
            		},
            		complete: function () {
            		}
        	});*/
	});
        //-->
    </script>

</head>
<body>

<?php echo $__env->make($skin.'public.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="main">

    <?php echo $__env->make($skin.'public.left', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="mainright">

        <div class="note">
            <div class="note_bar">
                <div class="t">
                    <input class="note_title" readonly="readonly"></input>
                    <span class="btn_edit layui-btn layui-btn-small layui-btn-radius layui-btn-primary">
                        <span class="fa fa-lock"></span>
                        <span class="font"> 编 辑</span>
                    </span>
                </div>
                <div class="b">
                    <span class="note_date">创建时间：2016/04/12</span>
                    <span class="note_update">更新时间：2016/06/12</span>
                </div>
            </div>
            <div class="note_content">

                <div class="note_content_html"></div>

                <div class="note_content_edit" data-id="">
                    <script id="container" name="content" type="text/plain"></script>
                </div>

            </div>
        </div>

    </div>

</div>

<?php echo $__env->make($skin.'public.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>

