<div class="main_left">

    <div class="scroll_left">

        <p><i class="icon icon-home" style="font-size:19px;"></i>个人笔记</p>

        <div class="content_wrap">
            <div class="zTreeDemoBackground left">
                <ul id="tree_cagegory" class="ztree"></ul>
            </div>
        </div>

    </div>

</div>

<div class="main_middle">
    <p>
        <span class="btn_view">
            <span class="fa fa-th"></span>
            <span class="fa fa-angle-down"></span>
        </span>

        <span class="btn_sort">
            <span class="fa fa-sort-alpha-asc"></span>
            <span class="fa fa-angle-down"></span>
        </span>
    </p>

    <div class="scroll_middle">

        <div class="middle_content">

            <?php $__empty_1 = true; $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="item" id="middle_content_item_<?php echo e($note->id); ?>" data-id="<?php echo e($note->id); ?>">
                    <div class="title"><?php echo e($note->title); ?></div>
                    <div class="info">
                        <span class="date"><?php echo e(date('Y/m/d H:i:s',$note->create_time)); ?></span>
                        <span class="dir"><?php echo e($note->category_id); ?></span>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <span class="no_note">该分类下无笔记</span>
            <?php endif; ?>

        </div>

    </div>

</div>

<div id="leftRightMenu" class="leftRightMenu">
    <ul class="ul">
        <li class="li" id="addNote" onclick="$.note.addNote();">新建笔记</li>
        <li class="li" id="addCategory" onclick="$.note.addCategory();">添加分类</li>
        <li class="li" id="categoryRename" onclick="$.note.categoryRename();">重命名</li>
        
        <li class="li" id="categoryMoveTo" onclick="$.note.categoryMoveTo();">移动到</li>
        <li class="li" id="categoryDelete" onclick="$.note.categoryDelete();">删除</li>
    </ul>
</div>


<div id="emptyLeftRightMenu" class="emptyLeftRightMenu">
    <ul class="ul">
        <li class="li" id="addCategory" onclick="$.note.addCategory();">添加分类</li>
    </ul>
</div>


<div id="middleRightMenu" class="middleRightMenu" data-id="">
    <ul class="ul">
        <li class="li" data-id="" id="noteShare" onclick="$.note.noteShare(this);">分享</li>
        
        <li class="li" data-id="" id="noteMoveTo" onclick="$.note.noteMoveTo(this);">移动到</li>
        <li class="li" data-id="" id="noteDelete" onclick="$.note.noteRemove(this);">删除</li>
    </ul>
</div>

<div id="middleViewMenu" class="middleViewMenu">
    <ul class="ul">
        <li class="li" id="viewAsDescription" onclick="$.note.viewAsDescription();">摘要</li>
        <li class="li" id="viewAsTwoLine" onclick="$.note.viewAsTwoLine();">两行</li>
        <li class="li" id="viewAsOneLine" onclick="$.note.viewAsOneLine();">一行</li>
    </ul>
</div>

<div id="middleSortMenu" class="middleSortMenu">
    <ul class="ul">
        <li class="li" id="sortByCreateTime" onclick="$.note.sortByCreateTime();">按创建时间排序</li>
        <li class="li" id="sortByUpdateTime" onclick="$.note.sortByUpdateTime();">按更新时间排序</li>
        <li class="li" id="sortByVistTime" onclick="$.note.sortByVistTime();">按访问时间排序</li>
        <li class="li" id="sortByTitle" onclick="$.note.sortByTitle();">按标题名排序</li>
    </ul>
</div>

<div id="data_collection" class="data_collection" data-tree-nodes="<?php echo e($tree); ?>" data-image-path="<?php echo e($path['image']); ?>"></div>

