<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>移动笔记</title>

    <!-- 基础样式及js 包括jquery，layui，layer等-->
    <?php echo $baseStatic; ?>


    <script type="text/javascript">
        <!--
        $(document).ready(function () {
            parent.$.note.conf.noteMoveTo.selectId = $(this).val();
            parent.$.note.conf.noteMoveTo.isCancel = false;
            $('.mc_select').change(function () {
                parent.$.note.conf.noteMoveTo.selectId = $(this).val();
            });
            $('.btn_mc').click(function () {
                parent.layer.close(parent.$.note.conf.noteMoveTo.layerFlag);
            });
        });
        //-->
    </script>

</head>
<body>


<div class="form_box">
    <form class="form_mc">
        <select class="mc_select" name="categoryId">
            <option value="0" selected="selected"> --- 请选择分类 --- </option>
            <?php echo $options; ?>

        </select>
        <a href="#" class="layui-btn layui-btn-normal btn_mc" onclick="return false;">确定</a>
    </form>
</div>


</body>
</html>




