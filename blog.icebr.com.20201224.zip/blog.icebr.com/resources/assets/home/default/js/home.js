/**
 * Created by PhpStorm.
 * User: icebr:ice_br2046@163.com
 * Date: 17-7-26
 * Time: 上午8:50
 */

layui.define(['element'], function (exports) {
    exports('home', {});

    $(document).ready(function () {
        $.note.init();
    });

});

/* note 对象 */
(function ($) {

    $.note = {

        /* 配置信息 */
        conf: {
            globals: {
                splitString: 'q_Y_p', /* 分割字符串 */
                ue: null,
                noParseContent: false,
                oldTitle: false,
                zNodes: {},
                zTree: {},
                addCount: 1,
                heightOffset: 16
            },
            init: {},

            checkAll: {
                group: '',
                head: '.check-head',
                item: '.check-item'
            },
            btnEditClick: {
                layerFlag: null,
            },

            btnReadClick: {
                layerFlag: null,
            },
            noteTitleBlur: {
                layerFlag: null,
            },
            categoryMoveTo: {
                layerFlag: null,
                selectId: null,
                isCancel: false
            },
            noteMoveTo: {
                layerFlag: null,
                selectId: null,
                isCancel: false
            },
            zTree: {
                setting: {
                    view: {
                        dblClickExpand: true,
                        autoCancelSelected: true
                    },
                    check: {
                        enable: false
                    },
                    callback: {
                        onRightClick: null,
                        beforeDrop: null,
                        onDrop: null,
                        onClick: null
                    },
                    data: {
                        simpleData: {
                            enable: true
                        }
                    },
                    edit: {
                        editNameSelectAll: false,
                        enable: true,
                        removeTitle: "remove",
                        renameTitle: "rename",
                        showRemoveBtn: false,
                        showRenameBtn: false,
                        drag: {
                            autoExpandTrigger: true,
                            isCopy: true,
                            isMove: true,
                            prev: true,
                            inner: true,
                            next: true,
                            borderMax: 10,
                            borderMin: -5,
                            minMoveSize: 5,
                            maxShowNodeNum: 5,
                            autoOpenTime: 500
                        }
                    }
                }
            },

            homeAjaxAsk: {
                layer: {}, /* layer 插件的参数 */
                ajax: {
                    url: '',
                    type: 'post',
                    cache: false,
                    data: null,
                    async: true,
                    dataType: 'text',
                    crossDomain: false,
                    headers: {
                        'X-XSRF-TOKEN': $.cookie('XSRF-TOKEN')
                    }
                },
                callback: {
                    beforeSend: null,
                    success: null,
                    complete: null
                }
            }
        },

        /* 初始化 */
        init: function (opt) {

            var opts = {}, sns = $.note;
            opts = $.extend(true, opts, this.conf.init, opt || {});

            this.resizeWindow();
            this.listenResize();

            if ($('.scroll_left').length > 0) {
                $('.scroll_left').niceScroll({
                    cursorcolor: '#ccc',
                    cursorborder: '0',
                    cursoropacitymax: '.7',
                    cursorwidth: '6',
                    horizrailenabled: true
                });
            }

            if ($('.scroll_middle').length > 0) {
                $('.scroll_middle').niceScroll({
                    cursorcolor: '#ccc',
                    cursorborder: '0',
                    cursoropacitymax: '.7',
                    cursorwidth: '6',
                    horizrailenabled: true,
                    railpadding: {top: 0, right: 0, left: -8, bottom: 0},
                });
            }

            this.listenItemContextmenu();
            this.listenItemClick();
            this.listenBtnViewMousedown();
            this.listenBtnSortMousedown();
            this.listenBtnEditClick();
            this.listenBtnReadClick();
            this.listenNoteTitleBlur();

            this.conf.globals.zNodes = $.parseJSON($('#data_collection').attr('data-tree-nodes'));
            this.zTreeSetCallback();

            $.fn.zTree.init($("#tree_cagegory"), this.conf.zTree.setting, this.conf.globals.zNodes);
            this.conf.globals.zTree = $.fn.zTree.getZTreeObj("tree_cagegory");
            this.conf.globals.rMenu = $("#leftRightMenu");
            this.conf.globals.mMenu = $("#middleRightMenu");

            if (this.conf.globals.zTree.getNodes().length < 1) {
                this.listenEmptyLeftContextmenu();
            }

        },

        zTreeSetCallback: function () {
            this.conf.zTree.setting.callback.onRightClick = this.onRightClick;
            this.conf.zTree.setting.callback.beforeDrop = this.beforeDrop;
            this.conf.zTree.setting.callback.onDrop = this.onDrop;
            this.conf.zTree.setting.callback.onClick = this.zTreeOnClick;
        },

        homeAjaxAsk: function (opt) {
            var opts = {};
            opts = $.extend(true, opts, $.note.conf.homeAjaxAsk, opt || {});

            $.ajax({
                url: opts.ajax.url,
                type: opts.ajax.type,
                cache: opts.ajax.cache,
                data: opts.ajax.data,
                async: opts.ajax.async,
                dataType: opts.ajax.dataType,
                crossDomain: opts.ajax.crossDomain,
                headers: opts.ajax.headers,
                beforeSend: function () {
                    opts.callback.beforeSend();
                },
                success: function (data) {
                    opts.callback.success(data);
                },
                complete: function () {
                    opts.callback.complete();
                }
            });
        },
        addNote: function () {
            $.note.hideRMenu();
            var selectNodes = $.note.conf.globals.zTree.getSelectedNodes();

            if (selectNodes[0]) {
                $.note.homeAjaxAsk({
                    ajax: {
                        url: '/addnote',
                        data: $.param(selectNodes[0])
                    },
                    callback: {
                        beforeSend: function () {
                            _mask = layer.msg('添加笔记中，请稍后...', {
                                icon: 16,
                                shade: 0.01
                            });
                        },
                        success: function (data) {

                            if (!data) {
                                return;
                            }
                            if (data == 'error') {
                                layer.msg('参数错误！');
                                return;
                            }

                            if (data == 'fail') {
                                layer.msg('添加失败！');
                                return;
                            }

                            data = $.parseJSON(data);

                            var tis = $('<div class="item" id="middle_content_item_' + data['id'] + '" data-id="' + data['id'] + '">' +
                                '<div class="title"></div>' +
                                '<div class="info">' +
                                '<span class="date">' + moment.unix(data['create_time']).format('YYYY/MM/DD HH:mm:ss') + '</span>' +
                                '<span class="dir"> ' + data['category_id'] + '</span>' +
                                '</div>' +
                                '</div>');
                            tis.prependTo($('.middle_content'));
                            layer.close(_mask);
                            $('.note_content_html').html('');
                            $.note.conf.globals.noParseContent = false;
                            tis.trigger('click');
                            $('.btn_edit').trigger('click');
                        },
                        complete: function () {
                            if (_mask) {
                                //layer.close(_mask);
                            }
                        }
                    }
                });

                return;

            }
        },

        onMouseUp: function (event, treeId, treeNode) {
            console.log(event);
        },

        beforeDrag: function (treeId, treeNodes) {
            for (var i = 0, l = treeNodes.length; i < l; i++) {
                if (treeNodes[i].drag === false) {
                    return false;
                }
            }
            return true;
        },

        checkTreeNode: function (checked) {
            var nodes = $.note.conf.globals.zTree.getSelectedNodes();
            if (nodes && nodes.length > 0) {
                $.note.conf.globals.zTree.checkNode(nodes[0], checked, true);
            }
            hideRMenu();
        },

        resetTree: function () {
            hideRMenu();
            $.fn.zTree.init($("#treeDemo"), setting, zNodes);
        },

        noteRemove: function (tis) {
            $.note.hideMMenu();
            var id = $(tis).attr('data-id');
            if (id > 0) {
                layer.confirm('确定删除此笔记吗？', function () {

                    $.note.homeAjaxAsk({
                        ajax: {
                            url: '/deletenote',
                            data: 'id=' + id
                        },
                        callback: {
                            beforeSend: function () {

                                _mask = layer.msg('删除笔记中，请稍后...', {
                                    icon: 16,
                                    shade: 0.01
                                });

                            },
                            success: function (data) {

                                if (!data) {
                                    return;
                                }
                                if (data == 'error') {
                                    layer.msg('参数错误！');
                                    return;
                                }

                                if (data == 'fail') {
                                    layer.msg('删除失败！');
                                    return;
                                }

                                if (data == 'img_delete_fail') {
                                    layer.msg('删除笔记中的图片失败！');
                                    return;
                                }

                                $('#middle_content_item_' + id).remove();
                                $.note.scrollResize();
                                $('.note_content_html').html('');
                                $('.note_bar').hide();
                                layer.msg('删除成功！');
                            },
                            complete: function () {
                                if (_mask) {
                                    layer.close(_mask);
                                }
                            }
                        }
                    });

                });
            }
        },


        categoryMoveTo: function (opt) {
            $.note.hideRMenu();
            var selectNode = $.note.conf.globals.zTree.getSelectedNodes()[0];

            if (selectNode) {

                $.note.conf.categoryMoveTo.layerFlag = layer.open({
                    type: 2,
                    title: '移动分类到...',
                    shadeClose: true,
                    shade: 0.8,
                    area: ['400px', '260px'],
                    content: '/movecategory',
                    success: function (layero, index) {
                        /*var body = layer.getChildFrame('body', index);
                         var iframeWin = window[layero.find('iframe')[0]['name']];
                         body.find('input').val('test');*/
                    },
                    cancel: function (index, layero) {
                        $.note.conf.categoryMoveTo.isCancel = true;
                    },
                    end: function () {

                        if ($.note.conf.categoryMoveTo.isCancel) {
                            return;
                        }

                        if (null === $.note.conf.categoryMoveTo.selectId) {
                            layer.msg('系统错误！');
                            return;
                        }
                        var lastNode = null;
                        var targetNode;
                        var moveType;

                        if ($.note.conf.categoryMoveTo.selectId == 0) {
                            var nodes = $.note.conf.globals.zTree.getNodes();
                            lastNode = nodes[nodes.length - 1];

                            targetNode = {id: 0, pid: 0, tid: 0};
                            moveType = 'next';
                            selectNode.pid = 0;
                            selectNode.tid = 0;

                        } else {
                            targetNode = $.note.conf.globals.zTree.getNodeByParam('id', $.note.conf.categoryMoveTo.selectId, false);
                            moveType = 'inner';
                            selectNode.pid = targetNode.id;
                            selectNode.tid = targetNode.tid;
                        }

                        $.note.homeAjaxAsk({
                            ajax: {
                                url: '/domovecategory',
                                data: $.param({'node': selectNode, 'target': targetNode})
                            },
                            callback: {
                                beforeSend: function () {

                                    _mask = layer.msg('移动分类中，请稍后...', {
                                        icon: 16,
                                        shade: 0.01
                                    });

                                },
                                success: function (data) {

                                    if (!data) {
                                        return;
                                    }
                                    if (data == 'error') {
                                        layer.msg('参数错误！');
                                        return;
                                    }

                                    if (data == 'fail') {
                                        layer.msg('移动失败！');
                                        return;
                                    }

                                    if (null !== lastNode) {
                                        $.note.conf.globals.zTree.moveNode(lastNode, selectNode, moveType);
                                    } else {
                                        $.note.conf.globals.zTree.moveNode(targetNode, selectNode, moveType);
                                    }

                                    $.note.conf.globals.zTree.updateNode(selectNode);
                                    $.note.scrollResize();
                                    layer.msg('移动成功！');
                                },
                                complete: function () {
                                    if (_mask) {
                                        layer.close(_mask);
                                    }
                                }
                            }
                        });

                    }
                });


                return;

            } else {
                $.note.conf.globals.zTree.addNodes(null, selectNode);
            }
        },

        noteMoveTo: function (opt) {
            $.note.hideMMenu();

            if (!opt) {
                layer.msg('系统错误！');
                return;
            }

            $.note.conf.noteMoveTo.layerFlag = layer.open({
                type: 2,
                title: '移动笔记到...',
                shadeClose: true,
                shade: 0.8,
                area: ['400px', '260px'],
                content: '/movenote',
                success: function (layero, index) {
                    /*var body = layer.getChildFrame('body', index);
                     var iframeWin = window[layero.find('iframe')[0]['name']];
                     body.find('input').val('test');*/
                },
                cancel: function (index, layero) {
                    $.note.conf.noteMoveTo.isCancel = true;
                },
                end: function () {
                    if ($.note.conf.noteMoveTo.isCancel) {
                        return;
                    }
                    if (null === $.note.conf.noteMoveTo.selectId) {
                        layer.msg('系统错误！');
                        return;
                    }

                    if ($.note.conf.noteMoveTo.selectId == 0) {
                        layer.msg('请选择一个分类！');
                        return;
                    } else {
                        var targetNode = $.note.conf.globals.zTree.getNodeByParam('id', $.note.conf.noteMoveTo.selectId, false);
                    }

                    $.note.homeAjaxAsk({
                        ajax: {
                            url: '/domovenote',
                            data: $.param({'note': {id: $(opt).attr('data-id')}, 'target': targetNode})
                        },
                        callback: {
                            beforeSend: function () {

                                _mask = layer.msg('移动笔记中，请稍后...', {
                                    icon: 16,
                                    shade: 0.01
                                });

                            },
                            success: function (data) {

                                if (!data) {
                                    return;
                                }
                                if (data == 'error') {
                                    layer.msg('参数错误！');
                                    return;
                                }

                                if (data == 'fail') {
                                    layer.msg('移动失败！');
                                    return;
                                }

                                layer.msg('移动成功！');
                            },
                            complete: function () {
                                if (_mask) {
                                    layer.close(_mask);
                                }
                            }
                        }
                    });

                }
            });


            return;

        },

        addCategory: function () {
            $.note.hideRMenu();
            var selectNode = $.note.conf.globals.zTree.getSelectedNodes()[0];
            var newNode = {name: "增加" + ($.note.conf.globals.addCount++)};
            if (selectNode) {
                newNode.pid = selectNode.id;
                newNode.tid = selectNode.tid;
                newNode.uid = selectNode.uid;
            } else {
                newNode.pid = 0;
                newNode.tid = 0;
            }

            layer.prompt({
                formType: 0,
                value: newNode.name,
                title: '请输入分类名',
                area: ['400px', '260px'] //自定义文本域宽高
            }, function (value, index, elem) {
                newNode.name = value;

                $.note.homeAjaxAsk({
                    ajax: {
                        url: '/addcategory',
                        data: $.param({'parent': selectNode, 'node': newNode})
                    },
                    callback: {
                        beforeSend: function () {

                            _mask = layer.msg('添加分类中，请稍后...', {
                                icon: 16,
                                shade: 0.01
                            });

                        },
                        success: function (data) {

                            if (!data) {
                                return;
                            }
                            if (data == 'error') {
                                layer.msg('参数错误！');
                                return;
                            }

                            if (data == 'exists') {
                                layer.msg('分类已存在！');
                                return;
                            }

                            if (data == 'fail') {
                                layer.msg('添加失败！');
                                return;
                            }

                            newNode.id = data;
                            newNode.checked = true;

                            if (selectNode) {
                                $.note.conf.globals.zTree.addNodes(selectNode, newNode);
                            } else {
                                $.note.conf.globals.zTree.addNodes(null, newNode);
                                $('.main_left').die("contextmenu mousedown");
                            }

                            layer.close(index);
                            layer.close(_mask);
                            layer.msg('添加成功！');
                        },
                        complete: function () {
                            if (_mask) {
                                layer.close(_mask);
                            }
                            if (index) {
                                layer.close(index);
                            }
                        }
                    }
                });


            });

            return;

        },

        categoryDelete: function () {
            $.note.hideRMenu();
            var nodes = $.note.conf.globals.zTree.getSelectedNodes();
            if (nodes && nodes.length > 0) {
                if (nodes[0].children && nodes[0].children.length > 0) {
                    layer.msg("要删除的节点包含子节点\n\n请先删除子节点！", function () {
                    });
                    return;
                } else {

                    $.note.homeAjaxAsk({
                        ajax: {
                            url: '/deletecategory',
                            data: $.param(nodes[0]),
                        },
                        callback: {
                            beforeSend: function () {

                                _mask = layer.msg('删除分类中，请稍后...', {
                                    icon: 16,
                                    shade: 0.01
                                });

                            },
                            success: function (data) {

                                if (!data) {
                                    return;
                                }
                                if (data == 'error') {
                                    layer.msg('参数错误！');
                                    return;
                                }

                                if (data == 'exists_child') {
                                    layer.msg('存在子分类！请先删除子分类！', function () {
                                    });
                                    return;
                                }

                                if (data == 'exists_blog') {
                                    layer.msg('分类下存在笔记！请先删除或移走笔记！', function () {
                                    });
                                    return;
                                }

                                if (data == 'fail') {
                                    layer.msg('删除失败！');
                                    return;
                                }

                                $.note.conf.globals.zTree.removeNode(nodes[0]);

                                if ($.note.conf.globals.zTree.getNodes().length < 1) {
                                    $.note.listenEmptyLeftContextmenu();
                                }
                                $.note.scrollResize();
                                layer.msg('删除成功！');
                            },
                            complete: function () {
                                if (_mask) {
                                    layer.close(_mask);
                                }
                            }
                        }
                    });

                }
            }
        },

        categoryRename: function () {
            $.note.hideRMenu();
            var nodes = $.note.conf.globals.zTree.getSelectedNodes();

            if (nodes[0]) {
                layer.prompt({
                    formType: 0,
                    value: nodes[0].name,
                    title: '请输入分类名',
                    area: ['400px', '260px'] //自定义文本域宽高
                }, function (value, index, elem) {
                    nodes[0].name = value;

                    $.note.homeAjaxAsk({
                        ajax: {
                            url: '/categoryrename',
                            data: $.param(nodes[0]),
                        },
                        callback: {
                            beforeSend: function () {
                                layer.close(index);
                                _mask = layer.msg('重命名中，请稍后...', {
                                    icon: 16,
                                    shade: 0.01
                                });
                            },
                            success: function (data) {

                                if (!data) {
                                    return;
                                }
                                if (data == 'error') {
                                    layer.msg('参数错误！');
                                    return;
                                }

                                if (data == 'fail') {
                                    layer.msg('重命名失败！');
                                    return;
                                }

                                $.note.conf.globals.zTree.updateNode(nodes[0]);
                                $.note.scrollResize();
                                layer.msg('重命名成功！', {icon: 6});
                            },
                            complete: function () {
                                if (_mask) {
                                    layer.close(_mask);
                                }
                                if (index) {
                                    layer.close(index);
                                }
                            }
                        }
                    });

                });
            }


        },


        onRightClick: function (event, treeId, treeNode) {
            if (!treeNode && event.target.tagName.toLowerCase() != "button" && $(event.target).parents("a").length == 0) {
                $.note.conf.globals.zTree.cancelSelectedNode();
                $.note.showRMenu("root", event.clientX, event.clientY);
            } else if (treeNode && !treeNode.noR) {
                $.note.conf.globals.zTree.selectNode(treeNode);
                $.note.showRMenu("node", event.clientX, event.clientY);
            }
        },

        showRMenu: function (type, x, y) {
            $("#leftRightMenu ul").show();
            if (type == "root") {
                $("#m_del").hide();
                $("#m_check").hide();
                $("#m_unCheck").hide();
            } else {
                $("#m_del").show();
                $("#m_check").show();
                $("#m_unCheck").show();
            }
            $.note.conf.globals.rMenu.css({"top": (y - 50) + "px", "left": x + "px", "display": "block"});

            $("body").bind("mousedown", $.note.onBodyMouseDown);
        },

        onBodyMouseDown: function (event) {
            if (!(event.target.id == "rMenu" || $(event.target).parents("#leftRightMenu").length > 0)) {
                $.note.conf.globals.rMenu.css({"display": "none"});
            }
        },

        beforeDrop: function (treeId, treeNodes, targetNode, moveType) {
            return targetNode ? targetNode.drop !== false : true;
        },

        onDrop: function (event, treeId, treeNodes, targetNode, moveType) {
            console.log(treeNodes.length + "," + (targetNode ? (targetNode.tId + ", " + targetNode.name) : "isRoot" ));
        },

        zTreeOnClick: function (event, treeId, treeNode) {
            var _data = {'id': treeNode.id};
            var _mask = false;

            $.note.homeAjaxAsk({
                ajax: {
                    url: '/getnotelist',
                    data: $.param(_data),
                },
                callback: {
                    beforeSend: function () {

                        _mask = $.i_mask.add({
                            insertBox: 'main_middle',
                            boxOffsetY: 50,
                            boxOffsetX: 211,
                        });

                    },
                    success: function (data) {
                        if (!data) {
                            return;
                        }
                        if (data == 'error') {
                            layer.msg('参数错误！');
                            return;
                        }

                        var _context = '';
                        data = $.parseJSON(data);

                        $('.middle_content').html('');

                        if (!data || !data[0]) {
                            _context = '<span class="no_note">该分类下无笔记</span>';
                        }

                        for (var dk in data) {

                            if (!data[dk]) {
                                continue;
                            }

                            var _data = data[dk];

                            _context += '<div class="item" id="middle_content_item_' + _data.id + '2" data-id="' + _data.id + '">' +
                                '<div class="title">' + _data.title + '</div>' +
                                '<div class="info">' +
                                '<span class="date">' + moment.unix(_data.create_time).format('YYYY/MM/DD HH:mm:ss') + ' </span>' +
                                '<span class="dir">' + _data.category_id + '</span>' +
                                '</div>' +
                                '</div>';
                        }

                        $(_context).appendTo($('.middle_content'));

                    },
                    complete: function () {

                        if (_mask) {
                            $.i_mask.remove(_mask);
                        }

                    }
                }
            });

        },

        hideRMenu: function () {
            if ($.note.conf.globals.rMenu) {
                $.note.conf.globals.rMenu.css({"display": "none"});
            }
            $("body").unbind("mousedown", $.note.onBodyMouseDown);
        },

        hideMMenu: function () {
            if ($.note.conf.globals.mMenu) {
                $.note.conf.globals.mMenu.css({"display": "none"});
            }
            $("body").unbind("mousedown", $.note.onBodyMouseDown);
        },

        listenBtnEditClick: function (opt) {
            var opts = {}, option;
            opts = $.extend(true, opts, this.conf.btnEditClick, opt || {});

            $('.btn_edit').live('click', function () {
                $('.note_content_html').find('img').unbind('click');
                $('.note_title').attr('readonly', false);
                $('.note_content_html').hide();
                $(this).removeClass('btn_edit').addClass('btn_read').find('.fa').removeClass('fa-lock').addClass('fa-unlock').end().find('.font').text('阅读');
                $('.note_content_edit').show();

                $.note.conf.globals.ue = UE.getEditor('container');

                $.note.conf.globals.ue.ready(function () {

                    $.note.resizeEditorContentHeight();

                    var con = $.note.conf.globals.ue.execCommand('drafts');

                    $.note.conf.globals.ue.setContent(!$.note.conf.globals.noParseContent ? $('.note_content_html').html() : $.note.conf.globals.noParseContent);
                    //ue.setHide();
                    $.note.conf.globals.ue.addListener('contentChange', function () {
                        var _con = '';
                        _con = $.note.conf.globals.ue.getContent();
                        try {
                            var imgList = '';
                            imgList = $(_con).find('img');
                            if (imgList.length > 0) {
                                var _imgs = false;
                                imgList.each(function () {
                                    if (!$(this).attr('src').match(/ueditor|api\.map\.baidu\.com\/staticimage|\.svg/)) {
                                        _imgs = true;
                                    }
                                });

                                if (_imgs) {
                                    opts.layerFlag = layer.msg('请稍等，正在获取内容中的远程图片，期间请勿保存直到提示成功！', {time: 30000});
                                }
                            }

                        } catch (e) {
                        }
                        $('.note_content_html').html(_con);
                    });

                    $.note.conf.globals.ue.addListener('catchremotesuccess', function () {
                        var _con = $.note.conf.globals.ue.getContent();
                        $('.note_content_html').html(_con);
                        layer.close(opts.layerFlag);
                        layer.msg('获取完毕！可以保存啦！');
                    });

                    $.note.conf.globals.ue.addListener('catchremoteerror', function () {
                        layer.close(opts.layerFlag);
                        layer.msg('获取失败！请清除内容重新粘贴！');
                    });

                });
            });
        },
        listenBtnReadClick: function (opt) {
            var opts = {}, option;
            opts = $.extend(true, opts, this.conf.btnReadClick, opt || {});

            $('.btn_read').live('click', function () {

                var _this = $(this);
                var _data = {'id': $('.note_title').attr('data-id'), 'content': $.note.conf.globals.ue.getContent()};
                $('.note_title').attr('readonly', true);

                if ($.note.conf.globals.noParseContent && $.note.conf.globals.noParseContent == _data.content) {
                    $('.note_content_edit').hide();
                    _this.removeClass('btn_read').addClass('btn_edit').find('.fa').removeClass('fa-unlock').addClass('fa-lock').end().find('.font').text('编辑');
                    $('.note_content_html').show();
                    uParse('.note_content_html');
                    $('.note_content_html').find('img').bind('click', $.note.imgClick);
                    return;
                }

                $.note.homeAjaxAsk({
                    ajax: {
                        url: '/savenotecontent',
                        data: $.param(_data)
                    },
                    callback: {
                        beforeSend: function () {
                            opts.layerFlag = layer.msg('保存内容中，请稍后...', {
                                icon: 16,
                                shade: 0.01
                            });
                        },
                        success: function (data) {
                            if (!data) {
                                return;
                            }
                            if (data == 'error') {
                                layer.msg('参数错误！');
                                return;
                            }

                            data = $.parseJSON(data);

                            if (!data) {
                                return;
                            }

                            $('.note_title').text(data['title']);
                            $('.note_update').text('更新日期：' + moment.unix(data['update_time']).format('YYYY/MM/DD HH:mm:ss'));
                            $('.note_content_edit').hide();
                            _this.removeClass('btn_read').addClass('btn_edit').find('.fa').removeClass('fa-unlock').addClass('fa-lock').end().find('.font').text('编辑');

                            $.note.conf.globals.noParseContent = data['content'];
                            $('.note_content_html').html(data['content']);
                            $.note.resizeNoteContentHeight();
                            $('.note_content_html').show();
                            uParse('.note_content_html');
                            layer.close(opts.layerFlag);

                            $('.note_content_html').find('img').bind('click', $.note.imgClick);

                        },
                        complete: function () {
                            if (opts.layerFlag) {
                                layer.close(opts.layerFlag);
                            }
                        }
                    }
                });
            });

        },

        listenNoteTitleBlur: function (opt) {
            var opts = {}, option;
            opts = $.extend(true, opts, this.conf.noteTitleBlur, opt || {});

            $('.note_title').blur(function () {

                if ($('.note_title').attr("readonly")) {
                    return;
                }
                var title = $('.note_title').val();
                if ($.note.conf.globals.oldTitle && $.note.conf.globals.oldTitle == title) {
                    return;
                }

                var _this = $(this);
                var _data = {'id': $('.note_title').attr('data-id'), 'title': title};

                $.note.homeAjaxAsk({
                    ajax: {
                        url: '/changetitle',
                        data: $.param(_data)
                    },
                    callback: {
                        beforeSend: function () {

                            opts.layerFlag = layer.msg('保存标题中，请稍后...', {
                                icon: 16,
                                time: 2,
                                shade: 0.01
                            });

                        },
                        success: function (data) {
                            if (!data) {
                                return;
                            }
                            if (data == 'error') {
                                layer.msg('参数错误！');
                                return;
                            }

                            data = $.parseJSON(data);

                            if (!data) {
                                return;
                            }

                            $.note.conf.globals.oldTitle = data['title'];
                            $('.note_title').val(data['title']);
                            $('.note_update').text('更新日期：' + moment.unix(data['update_time']).format('YYYY/MM/DD HH:mm:ss'));
                            $('.middle_content_item_select').find('.title').text(data['title']);
                            layer.close(opts.layerFlag);

                        },
                        complete: function () {
                            if (opts.layerFlag) {
                                layer.close(opts.layerFlag);
                            }
                        }
                    }
                });

            });


        },

        listenBtnViewMousedown: function () {
            $('.btn_view').live('mousedown', function (e) {
                switch (e.which) {
                    case 3:
                        break;
                    case 1:
                        $(this).css('color', '#f7b824');
                        $.note.showMiddleViewMenu("node", e.clientX, e.clientY);
                        break;
                }
            });
        },
        listenBtnSortMousedown: function () {
            $('.btn_sort').live('mousedown', function (e) {
                switch (e.which) {
                    case 3:
                        break;
                    case 1:
                        $(this).css('color', '#f7b824');
                        $.note.showMiddleSortMenu("node", e.clientX, e.clientY);
                        break;
                }
            });
        },

        listenEmptyLeftContextmenu: function () {

            $('.main_left').live("contextmenu", function (e) {
                return false;
            }).live('mousedown', function (e) {
                switch (e.which) {
                    case 3:
                        $.note.showEmptyLeftRightMenu("node", e.clientX, e.clientY, e);
                        break;
                }
            });
        },


        listenItemContextmenu: function () {
            $(".middle_content .item").live("contextmenu", function (e) {
                return false;
            }).live('mousedown', function (e) {
                switch (e.which) {
                    case 3:
                        $(this).addClass('middle_content_item_pop');
                        $.note.showMiddleRightMenu("node", e.clientX, e.clientY, e, $(this).attr('data-id'));
                        break;
                }
            });
        },

        listenItemClick: function () {
            $(".middle_content .item").live('click', function (e) {
                if ($(".note_content_html").is(":hidden")) {
                    layer.msg('请关闭右侧编辑界面之后操作！');
                    return;
                }
                $(this).siblings('.item').removeClass('middle_content_item_select').end().addClass('middle_content_item_select');
                $.note.getNoteContent($(this));
            });
        },

        listenResize: function () {
            $.note.resizeWindow();
            $.note.scrollResize();
            $(window).resize(function () {
                $.note.resizeWindow();
                $.note.scrollResize();
            });
        },

        resizeWindow: function () {
            var headerBox = $('.header');
            /*$('.main').height($(window).height() - $('.main').offset().top);*/
            $.note.resizeNoteContentHeight();
            try {
                $.note.resizeEditorContentHeight();
            } catch (e) {

            }
        },

        resizeNoteContentHeight: function () {
            var h = $(window).height() - $('.note_content').offset().top;
            $('.note_content_html').css('height', h - h * 0.02 - $.note.conf.globals.heightOffset);
        },

        resizeEditorContentHeight: function () {
            var h = $(window).height() - $('#edui1_iframeholder').offset().top;
            $.note.conf.globals.ue.setHeight(h);
        },

        scrollResize: function () {
            if ($('.scroll_left').height() > 0) {
                $('.scroll_left').height($(window).height() - $('.scroll_left').offset().top);
            }
            if ($('.scroll_middle').height() > 0) {
                $('.scroll_middle').height($(window).height() - $('.scroll_middle').offset().top);
            }
        },

        getNoteContent: function (node) {

            var _data = {'id': node.attr('data-id')};

            $.note.homeAjaxAsk({
                ajax: {
                    url: '/getnotecontent',
                    data: $.param(_data)
                },
                callback: {
                    beforeSend: function () {

                        _mask = $.i_mask.add({
                            insertBox: 'mainright',
                            boxOffsetX: 432,
                            boxOffsetY: 50,
                        });

                    },
                    success: function (data) {
                        if (!data) {
                            return;
                        }
                        if (data == 'error') {
                            layer.msg('参数错误！');
                            return;
                        }

                        data = $.parseJSON(data);

                        if (!data) {
                            return;
                        }

                        $('.note_content_html').html('');
                        $('.note_bar').show();
                        $('.note_title').val(data['title']).attr('data-id', data['id']);
                        $('.note_date').text('创建日期：' + moment.unix(data['create_time']).format('YYYY/MM/DD HH:mm:ss'));
                        $('.note_update').text('更新日期：' + moment.unix(data['update_time']).format('YYYY/MM/DD HH:mm:ss'));

                        $.note.conf.globals.noParseContent = data['content'];
                        $('.note_content_html').html(data['content']);
                        $.note.resizeNoteContentHeight();
                        uParse('.note_content_html');
                        $('.note_content_html').find('img').bind('click', $.note.imgClick);
                    },
                    complete: function () {
                        if (_mask) {
                            $.i_mask.remove(_mask);
                        }
                    }
                }
            });

        },

        imgClick: function () {

            var photoJson = {
                "title": "", //相册标题
                "id": 123, //相册id
                "start": 0, //初始显示的图片序号，默认0
                "data": []
            };

            $('.note_content_html').find('img').each(function (i) {
                photoJson.data[i] = {
                    'alt': $(this).attr('title'),
                    'pid': $(this).attr('id'),
                    'src': $(this).attr('src'),
                    'thumb': $(this).attr('src')
                };
            });

            layer.photos({
                photos: photoJson
                , anim: 5 //0-6的选择，指定弹出图片动画类型，默认随机（请注意，3.0之前的版本用shift参数）
            });

            return false;

        },

        showMiddleViewMenu: function (type, x, y) {
            $("#middleViewMenu ul").show();
            $("#middleViewMenu").css({"top": (y - 50) + "px", "left": x + "px", "display": "block"});
            $("body").bind("mousedown", this.onBodyMouseDownForViewMenu);
        },

        onBodyMouseDownForViewMenu: function (event) {
            if (1 == event.which) {
                $('.btn_view').css('color', '#ccc');
                if (!(event.target.id == "middleViewMenu" || $(event.target).parents("#middleViewMenu").length > 0)) {
                    $("#middleViewMenu").css({"display": "none"});
                }
            }
        },

        showMiddleSortMenu: function (type, x, y) {
            $("#middleSortMenu ul").show();
            $("#middleSortMenu").css({"top": (y - 50) + "px", "left": x + "px", "display": "block"});
            $("body").bind("mousedown", $.note.onBodyMouseDownForSortMenu);
        },

        onBodyMouseDownForSortMenu: function (event) {
            if (1 == event.which) {
                $('.btn_sort').css('color', '#ccc');
                if (!(event.target.id == "middleSortMenu" || $(event.target).parents("#middleSortMenu").length > 0)) {
                    $("#middleSortMenu").css({"display": "none"});
                }
            }
        },

        showMiddleRightMenu: function (type, x, y, e, dataId) {
            $("#middleRightMenu").attr('data-id', dataId).find('li').attr('data-id', dataId).end().show();
            $("#middleRightMenu").css({
                "top": (y - 50) + "px",
                "left": x + "px",
                "display": "block"
            }).live('contextmenu', function () {
                return false;
            });
            $("body").bind("mousedown", $.note.onBodyMouseDownForRightMenu);
        },

        showEmptyLeftRightMenu: function (type, x, y, e) {
            $("#emptyLeftRightMenu").show();
            $("#emptyLeftRightMenu").css({
                "top": (y - 50) + "px",
                "left": x + "px",
                "display": "block"
            }).live('contextmenu', function () {
                return false;
            });
            $("body").bind("mousedown", $.note.onBodyMouseDownForEmptyLeftRightMenu);
        },

        onBodyMouseDownForEmptyLeftRightMenu: function (event) {
            if (1 == event.which) {
                if (!(event.target.id == "emptyLeftRightMenu" || $(event.target).parents("#emptyLeftRightMenu").length > 0)) {
                    $("#emptyLeftRightMenu").css({"display": "none"});
                    $("body").unbind("mousedown", $.note.onBodyMouseDownForEmptyLeftRightMenu);
                }
            }
        },


        onBodyMouseDownForRightMenu: function (event) {
            if (1 == event.which) {
                $('.middle_content .item').removeClass('middle_content_item_pop');
                if (!(event.target.id == "middleRightMenu" || $(event.target).parents("#middleRightMenu").length > 0)) {
                    $("#middleRightMenu").css({"display": "none"});
                    $("body").unbind("mousedown", $.note.onBodyMouseDownForRightMenu);
                }
            }
        },

        htmlencode: function (s) {
            var div = document.createElement('div');
            div.appendChild(document.createTextNode(s));
            return div.innerHTML;
        },

        htmldecode: function (s) {
            var div = document.createElement('div');
            div.innerHTML = s;
            return div.innerText || div.textContent;
        },

        isDOM: ( typeof HTMLElement === 'object' ) ?
            function (obj) {
                return obj instanceof HTMLElement;
            } :
            function (obj) {
                return obj && typeof obj === 'object' && obj.nodeType === 1 && typeof obj.nodeName === 'string';
            },

        /* 全选实现
         * @head 全选按钮的class名
         * @group 一个页面有多组checkbox时 check-head的父元素
         * @item 要选择的所有input的class名
         * */
        checkAll: function (opt) {
            var opts = {}, option;
            opts = $.extend(true, opts, this.conf.checkAll, opt || {});

            $(opts.head).bind('click', function (event) {
                event.stopPropagation();

                if (opts.group) {
                    $(this).parent(opts.group).nextUntil(opts.group).find(opts.item).prop("checked", this.checked);
                } else {
                    $(opts.item).prop("checked", this.checked);
                }

            });
            $(opts.item).bind('click', function (event) {
                event.stopPropagation();
                var head, group, items;
                if (opts.group) {
                    group = $(this).parent().prevAll(opts.group).first();
                    head = group.children(opts.head);
                    items = group.nextUntil(opts.group).find(opts.item);
                } else {
                    head = $(opts.head);
                    items = $(opts.item);
                }

                items.each(function (i) {
                    if (!this.checked) {
                        head.prop("checked", false);
                        return false;
                    }
                    head.prop("checked", true);
                });

            });
        },

        /* 根据select更新相关input值 */
        selectChange: function (select, input) {
            if (select.length < 1 || input.length < 1) {
                return;
            }
            if (input.val() == '') {
                input.val(select.find('option').first().attr('title'));
            }
            select.on('change', function () {
                input.val($(this).find('option:selected').attr('title'));
            });
        },

        /* 设置表单的值 */
        setValue: function (name, value) {
            var first = name.substr(0, 1), input, i = 0, val;
            if (value === "") return;

            if ("#" === first || "." === first) {
                input = $(name);
            } else {
                input = $("[name='" + name + "']");
            }

            if (input.eq(0).is(":radio")) { //单选按钮
                input.filter("[value='" + value + "']").each(function () {
                    this.checked = true
                });
            } else if (input.eq(0).is(":checkbox")) { //复选框
                if (!$.isArray(value)) {
                    val = new Array();
                    val[0] = value;
                } else {
                    val = value;
                }
                for (i = 0, len = val.length; i < len; i++) {
                    input.filter("[value='" + val[i] + "']").each(function () {
                        this.checked = true
                    });
                }
            } else {  //其他表单选项直接设置值
                input.val(value);
            }
        },

        /* 后退并刷新 */

        goBack: function (opt, refresh) {
            if (!refresh) {
                history.go(opt);
            } else {
                history.back(opt);
            }
        },
        /* json对象转换成字符串：：用于测试 */
        obj2string: function (o) {
            var r = [];
            if (typeof o == "string") {
                return "\"" + o.replace(/(['"\\])/g, "\\$1").replace(/(\n)/g, "\\n").replace(/(\r)/g, "\\r").replace(/(\t)/g, "\\t") + "\"";
            }
            if (typeof o == "object") {
                var i;
                if (!o.sort) {
                    for (i in o) {
                        r.push(i + ":" + obj2string(o[i]));
                    }
                    if (!!document.all && !/^\n?function\s*toString\(\)\s*\{\n?\s*\[native code\]\n?\s*\}\n?\s*$/.test(o.toString)) {
                        r.push("toString:" + o.toString.toString());
                    }
                    r = "{" + r.join() + "}";
                } else {
                    for (i = 0; i < o.length; i++) {
                        r.push(obj2string(o[i]))
                    }
                    r = "[" + r.join() + "]";
                }
                return r;
            }
            return o.toString();
        },

        /**
         * 和PHP一样的时间戳格式化函数
         * @param {string} format 格式
         * @param {int} timestamp 要格式化的时间 默认为当前时间
         * @return {string}   格式化的时间字符串
         */
        date: function (format, timestamp) {
            var a, jsdate = ((timestamp) ? new Date(timestamp * 1000) : new Date());
            var pad = function (n, c) {
                if ((n = n + "").length < c) {
                    return new Array(++c - n.length).join("0") + n;
                } else {
                    return n;
                }
            };
            var txt_weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
            var txt_ordin = {1: "st", 2: "nd", 3: "rd", 21: "st", 22: "nd", 23: "rd", 31: "st"};
            var txt_months = ["", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            var f = {
                // Day
                d: function () {
                    return pad(f.j(), 2)
                },
                D: function () {
                    return f.l().substr(0, 3)
                },
                j: function () {
                    return jsdate.getDate()
                },
                l: function () {
                    return txt_weekdays[f.w()]
                },
                N: function () {
                    return f.w() + 1
                },
                S: function () {
                    return txt_ordin[f.j()] ? txt_ordin[f.j()] : 'th'
                },
                w: function () {
                    return jsdate.getDay()
                },
                z: function () {
                    return (jsdate - new Date(jsdate.getFullYear() + "/1/1")) / 864e5 >> 0
                },

                // Week
                W: function () {
                    var a = f.z(), b = 364 + f.L() - a;
                    var nd2, nd = (new Date(jsdate.getFullYear() + "/1/1").getDay() || 7) - 1;
                    if (b <= 2 && ((jsdate.getDay() || 7) - 1) <= 2 - b) {
                        return 1;
                    } else {
                        if (a <= 2 && nd >= 4 && a >= (6 - nd)) {
                            nd2 = new Date(jsdate.getFullYear() - 1 + "/12/31");
                            return date("W", Math.round(nd2.getTime() / 1000));
                        } else {
                            return (1 + (nd <= 3 ? ((a + nd) / 7) : (a - (7 - nd)) / 7) >> 0);
                        }
                    }
                },

                // Month
                F: function () {
                    return txt_months[f.n()]
                },
                m: function () {
                    return pad(f.n(), 2)
                },
                M: function () {
                    return f.F().substr(0, 3)
                },
                n: function () {
                    return jsdate.getMonth() + 1
                },
                t: function () {
                    var n;
                    if ((n = jsdate.getMonth() + 1) == 2) {
                        return 28 + f.L();
                    } else {
                        if (n & 1 && n < 8 || !(n & 1) && n > 7) {
                            return 31;
                        } else {
                            return 30;
                        }
                    }
                },

                // Year
                L: function () {
                    var y = f.Y();
                    return (!(y & 3) && (y % 1e2 || !(y % 4e2))) ? 1 : 0
                },
                //o not supported yet
                Y: function () {
                    return jsdate.getFullYear()
                },
                y: function () {
                    return (jsdate.getFullYear() + "").slice(2)
                },

                // Time
                a: function () {
                    return jsdate.getHours() > 11 ? "pm" : "am"
                },
                A: function () {
                    return f.a().toUpperCase()
                },
                B: function () {
                    // peter paul koch:
                    var off = (jsdate.getTimezoneOffset() + 60) * 60;
                    var theSeconds = (jsdate.getHours() * 3600) + (jsdate.getMinutes() * 60) + jsdate.getSeconds() + off;
                    var beat = Math.floor(theSeconds / 86.4);
                    if (beat > 1000) beat -= 1000;
                    if (beat < 0) beat += 1000;
                    if ((String(beat)).length == 1) beat = "00" + beat;
                    if ((String(beat)).length == 2) beat = "0" + beat;
                    return beat;
                },
                g: function () {
                    return jsdate.getHours() % 12 || 12
                },
                G: function () {
                    return jsdate.getHours()
                },
                h: function () {
                    return pad(f.g(), 2)
                },
                H: function () {
                    return pad(jsdate.getHours(), 2)
                },
                i: function () {
                    return pad(jsdate.getMinutes(), 2)
                },
                s: function () {
                    return pad(jsdate.getSeconds(), 2)
                },
                //u not supported yet

                // Timezone
                //e not supported yet
                //I not supported yet
                O: function () {
                    var t = pad(Math.abs(jsdate.getTimezoneOffset() / 60 * 100), 4);
                    if (jsdate.getTimezoneOffset() > 0) t = "-" + t; else t = "+" + t;
                    return t;
                },
                P: function () {
                    var O = f.O();
                    return (O.substr(0, 3) + ":" + O.substr(3, 2))
                },
                //T not supported yet
                //Z not supported yet

                // Full Date/Time
                c: function () {
                    return f.Y() + "-" + f.m() + "-" + f.d() + "T" + f.h() + ":" + f.i() + ":" + f.s() + f.P()
                },
                //r not supported yet
                U: function () {
                    return Math.round(jsdate.getTime() / 1000)
                }
            };

            return format.replace(/[\\]?([a-zA-Z])/g, function (t, s) {
                if (t != s) {
                    // escaped
                    ret = s;
                } else if (f[s]) {
                    // a date function exists
                    ret = f[s]();
                } else {
                    // nothing special
                    ret = s;
                }
                return ret;
            });
        }

    };

})(jQuery);

/* 封装的遮罩层 */
(function ($) {
    $.i_mask = {
        add: function (opt) {

            var opts = $.extend({
                insertBox: 'r_con',
                boxOffsetX: 0,
                boxOffsetY: 0,
                offsetX: 0,
                offsetY: 0,
                box: "zzbg_box",
                mask: 'zzbg',
                icon: 't_load',
                iconSrc: $('#data_collection').attr('data-image-path') + '/load_98.gif'
            }, opt || {});

            var _insertBox = $('.' + opts.insertBox);

            _insertBox.append('<div class="' + opts.box + '"><div class="' + opts.mask + '"></div><img class="' + opts.icon + '" src="' + opts.iconSrc + '" /></div>');

            var _box = $('.' + opts.box),
                _mask = $('.' + opts.mask),
                _icon = $('.' + opts.icon);

            _box.width(_insertBox.width()).height(_insertBox.height());
            _mask.width(_insertBox.width()).height(_insertBox.height());

            _box.css({
                'top': opts.boxOffsetY,
                'left': opts.boxOffsetX
            });

            _icon.css({
                'top': (_box.height() - _icon.height()) / 2 + opts.offsetY,
                'left': (_box.width() - _icon.width()) / 2 + opts.offsetX
            });

            return _box;
        },
        remove: function (opt) {
            opt.remove();
        }
    };

})(jQuery);









