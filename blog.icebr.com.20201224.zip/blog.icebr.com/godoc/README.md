go语言标准库中文文档  
对官方文档http://godoc.org/  的开源翻译项目  
添加全文搜索功能,框架导航布局,源码链接到github  
golang标准库手册 简短域名 http://godoc.ml/
