<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<?php
function msubstr($str, $start=0, $length, $charset="utf-8", $suffix=true) {
    if(function_exists("mb_substr"))
        $slice = mb_substr($str, $start, $length, $charset);
    elseif(function_exists('iconv_substr')) {
        $slice = iconv_substr($str,$start,$length,$charset);
        if(false === $slice) {
            $slice = '';
        }
    }else{
        $re['utf-8']   = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";
        $re['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";
        $re['gbk']    = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";
        $re['big5']   = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";
        preg_match_all($re[$charset], $str, $match);
        $slice = join("",array_slice($match[0], $start, $length));
    }
    return $suffix ? $slice.'...' : $slice;
}
if ($_GET['s'] != "") {
    echo '<a href="main.html"><h2>返回首页</h2></a>';
    echo "搜索(", $_GET['s'], ')结果如下:</br>';
    foreach (glob("pkg/*.htm") as $name) {
        $s = file_get_contents($name);
        $pos = strpos($s, $_GET['s']);
        if ($pos != false) {
            echo '<a href="', $name, '"><h2>', $name, '</h2></a>',
'<a href="',$name,'#',$_GET['s'],'"><span style="color: red;font-weight: bold;margin-right: 20px;">',$_GET['s']. '</span>... ', msubstr($s, $pos - 360, 500),'</a>',
            msubstr($s, $pos, 120);
        }
    }
}
?>
